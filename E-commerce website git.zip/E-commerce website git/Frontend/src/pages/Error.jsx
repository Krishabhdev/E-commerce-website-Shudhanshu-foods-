import React from 'react'

const Error = () => {
  return (
    <div>
      <h1 className='text-center' >Enter Right Path</h1>
    </div>
  )
}

export default Error
